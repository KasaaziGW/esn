# Emergency Social Network [ESN]
This is the final project dubbed "Emergency Social Network [ESN]" that the whole class is going to contribute to.
